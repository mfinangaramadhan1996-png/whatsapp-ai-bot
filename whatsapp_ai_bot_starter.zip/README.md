# WhatsApp AI Bot (Kiswahili) — Starter

Bot hii inajibu **WhatsApp** (kupitia Twilio) kwa **Kiswahili**, ikiwa na **rule-based** fallback na **OpenAI (hiari)** kwa majibu ya akili zaidi.

## Vipengele
- ✅ Inafanya kazi na **Twilio WhatsApp Sandbox** au WhatsApp Business API
- ✅ **Kiswahili-first** rules (salamu, bei, muda wa kazi, oda)
- ✅ Hiari: **OpenAI** kwa majibu bora (weka `OPENAI_API_KEY`)
- ✅ Inaweza ku-hostiwa kwa urahisi (Render/Fly.io/Heroku/Docker/VPS)

---

## 1) Mahitaji
- Akaunti ya **Twilio** (WhatsApp Sandbox) — free kuanza
- Python 3.10+
- (Hiari) **OPENAI_API_KEY** kama unataka majibu ya AI

---

## 2) Kuanzia Haraka (Local)

```bash
git clone <repo au unzip>
cd whatsapp_ai_bot_starter
python -m venv .venv && source .venv/bin/activate
pip install -r requirements.txt

# tengeneza .env
cp .env.example .env
# hariri .env kuweka BIZ_NAME na (hiari) OPENAI_API_KEY
# kisha anzisha server
python app.py
```

Server itasikiza `http://localhost:8000/` na webhook ya WhatsApp ni `POST /whatsapp`.

### Expose Localhost kwa Twilio
Tumia ngrok au Cloudflared:
```bash
ngrok http 8000
```
Chukua URL ya ngrok (mf. `https://abc123.ngrok.io/whatsapp`) na uiweke Twilio: **Sandbox > When a message comes in**.

---

## 3) Twilio WhatsApp Sandbox (Quick Setup)
1. Fungua Twilio Console → Messaging → Try it out → **WhatsApp Sandbox**  
2. Fuata maelekezo ya kujiunga na namba ya sandbox (utume neno lililoelekezwa WhatsApp).  
3. Weka webhook URL ya `POST` kwenye **/whatsapp** (mf. `https://your-domain/whatsapp`).  
4. Tuma ujumbe wa majaribio kutoka WhatsApp yako → bot atajibu.

---

## 4) Deployment (Render mfano)
- Push code GitHub
- Render.com → New Web Service → poa Python
- Build: `pip install -r requirements.txt`
- Start command: `gunicorn app:app`
- Add Environment Variables: `BIZ_NAME`, (hiari) `OPENAI_API_KEY`
- Chukua URL ya Render na uiweke Twilio WhatsApp webhook

---

## 5) Kubadilisha Majibu
Angalia `rule_based_reply()` ndani ya `app.py`. Ongeza sheria zako kwa bidhaa/bei/maswali ya biashara yako.

Mfano:
```python
if "simu" in m:
    return "Simu hii inauzwa TZS 350,000 na dhamana ya miezi 12."
```

---

## 6) Usalama na Uendeshaji
- Thibitisha requests zinatoka Twilio (Twilio Request Validation) — angalia docs za Twilio.
- Ongeza logging/metrics (mf. Sentry) ukianza kupata wateja.
- Hakikisha unafuata sera za WhatsApp Business (message templates kwa outbound).

---

## 7) Maswali ya Mara kwa Mara
**Q:** Lazima niwe na OpenAI?  
**A:** Hapana. Bila OpenAI, bot itatumia rules (zipo tayari).

**Q:** Nawezaje kuongeza Facebook/Instagram?  
**A:** Tumia Meta Graph API (Messenger/Instagram) au huduma kama Twilio Conversations. Mantiki ya kujibu inaweza kubaki ile ile (REST endpoint nyingine).

**Q:** Je, inaweza ku-turn into subscription SaaS?  
**A:** Ndiyo. Tumia multi-tenant approach: hifadhi token/credentials kwa mteja kila mmoja na utengeneze dashboard.

---

Imetengenezwa kama **starter** ili uanze haraka. Ukitaka feature zaidi (DB, dashboard, multi-channel), ongeza hatua kwa hatua.
