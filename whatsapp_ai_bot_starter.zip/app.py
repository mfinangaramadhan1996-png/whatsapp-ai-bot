import os
from flask import Flask, request, Response
from twilio.twiml.messaging_response import MessagingResponse
from datetime import datetime
import re

# Optional: Use OpenAI for smarter replies (only if OPENAI_API_KEY is set)
USE_OPENAI = bool(os.getenv("OPENAI_API_KEY"))
if USE_OPENAI:
    try:
        from openai import OpenAI
        client = OpenAI(api_key=os.getenv("OPENAI_API_KEY"))
    except Exception as e:
        USE_OPENAI = False

app = Flask(__name__)

def rule_based_reply(msg: str) -> str:
    """Very simple Kiswahili-first rules as a fallback if no OpenAI key."""
    m = msg.lower().strip()

    # Greetings
    if any(g in m for g in ["mambo", "habari", "vipi", "hello", "hi", "hey"]):
        return "Habari! 😊 Karibu. Naweza kukusaidiaje leo?"

    # Pricing / bei
    if any(k in m for k in ["bei", "price", "gharama"]):
        return ("Bei zetu ziko wazi: \n"
                "- Package Basic: TZS 50,000/mwezi (WhatsApp tu)\n"
                "- Standard: TZS 100,000/mwezi (WhatsApp + Facebook)\n"
                "- Premium: TZS 200,000/mwezi (Multi-channel + SMS)\n"
                "Ungependa ipi?")

    # Working hours / muda
    if any(k in m for k in ["saa ngapi", "mnafunga", "mnashift", "opening hours", "mnafunga saa", "mnafunguaga"]):
        return "Tunapatikana Jumatatu–Ijumaa 8:00–18:00, Jumamosi 9:00–16:00. Karibu!"

    # Orders / oda
    if any(k in m for k in ["oda", "order", "nitengenezee", "nisajilie", "nijiunge"]):
        return ("Asante kwa nia yako 🧾. Tafadhali tuma: \n"
                "1) Jina kamili \n2) Namba ya mawasiliano \n3) Huduma unayohitaji \n"
                "Tutakujibu muda si mrefu na maelezo kamili.")

    # Thanks
    if any(k in m for k in ["asante", "thank"]):
        return "Karibu sana! Ukihitaji chochote, andika tu hapa. 🙌"

    # Fallback
    return ("Nashukuru kwa ujumbe wako. Tafadhali fafanua unachohitaji "
            "au uliza kuhusu bei, muda wa kazi, au oda — niko hapa kusaidia. 🙂")

def openai_reply(prompt: str) -> str:
    """If OpenAI is available, generate a friendly Kiswahili reply."""
    try:
        if not USE_OPENAI:
            return rule_based_reply(prompt)

        system_msg = (
            "Wewe ni msaidizi wa biashara unayeandika kwa Kiswahili fasaha, "
            "ukijibu kwa ufupi, wazi, na kuelekeza hatua inayofuata."
        )
        completion = client.chat.completions.create(
            model=os.getenv("OPENAI_MODEL", "gpt-4o-mini"),
            messages=[
                {"role": "system", "content": system_msg},
                {"role": "user", "content": prompt}
            ],
            temperature=0.4,
            max_tokens=300,
        )
        text = completion.choices[0].message.content.strip()
        return text or rule_based_reply(prompt)
    except Exception:
        return rule_based_reply(prompt)

@app.route("/", methods=["GET"])
def health():
    return {"ok": True, "time": datetime.utcnow().isoformat()}

@app.route("/whatsapp", methods=["POST"])
def whatsapp_webhook():
    """Twilio will POST WhatsApp messages here. Reply with TwiML."""
    incoming_msg = request.form.get("Body", "") or ""
    from_number = request.form.get("From", "")
    # Optional: read business name from env
    biz_name = os.getenv("BIZ_NAME", "Biashara Yako")
    # Generate a reply
    reply_text = openai_reply(incoming_msg)

    # Wrap in Twilio MessagingResponse
    resp = MessagingResponse()
    msg = resp.message()
    msg.body(f"{reply_text}\n\n— {biz_name}")
    return Response(str(resp), mimetype="application/xml")

if __name__ == "__main__":
    port = int(os.getenv("PORT", "8000"))
    app.run(host="0.0.0.0", port=port)
